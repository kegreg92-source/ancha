@echo off 
npm start
